import React, { useContext } from 'react'
import { ShopContext } from '../Context/ShopContext'
import dropdown_icon from "../Components/Assets/Frontend_Assets/dropdown_icon.png"
import Item from '../Components/Item/Item'

const ShopCategory = (props) => {
  const {all_product} = useContext(ShopContext)
  return (
    <div className='shop-category mt-14 '>
      <img src={props.banner} alt="" />
      <div className="shop-category-indexSort flex justify-between px-14 py-8">
        <p>
          <span className='font-bold' >Showing 1-12</span> out of 36 products
        </p>
        <div className="shopcategory-sort flex items-center gap-2">
          Sort by<img className='invert' src={dropdown_icon} alt="" />
        </div>
      </div>
      <div className="shopcategory-products grid grid-cols-4 gap-8 mx-4">
        {all_product.map((item,i)=>{
          if(props.category===item.category){
            return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
          } else {
            return null
          }
        })}
      </div>

      <div className="shopcategory-loadmore bg-purple-800 flex justify-center items-center w-1/5 py-4 mx-auto my-20 rounded-full text-xl font-bold cursor-pointer hover:bg-purple-700">
        Explore More
      </div>
    </div>
  )
}

export default ShopCategory

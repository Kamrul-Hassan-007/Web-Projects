import React, { useState } from 'react'

const LoginSignup = () => {

  const [state, setState] = useState('Log In')
  const [formData, setFormData] = useState({
    username:"",
    email:"",
    password:"",
  })

  const changeHandler = (e) => {
    setFormData({...formData,[e.target.name]:e.target.value})
  }
  


  const login = async () => {
    
    let res = await fetch('http://localhost:4000/login',{
      method:"POST",
      headers:{
        Accept:'application/form-data',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(formData)
    })

    let metaData = await res.json()
    let responseData = await metaData

    if(responseData.success){
      localStorage.setItem('auth-token',responseData.token)
      window.location.replace('/')
    }else{
      alert(responseData.errors)
    }
  }
  
  
  const signup = async () => {

    let res = await fetch('http://localhost:4000/signup',{
      method:"POST",
      headers:{
        Accept:'application/form-data',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(formData)
    })

    let metaData = await res.json()
    let responseData = await metaData

    if(responseData.success){
      localStorage.setItem('auth-token',responseData.token)
      window.location.replace('/')
    }else{
      alert(responseData.errors)
    }
  }


  return (
    <div className='loginSignup bg-gray-800 mt-14 w-full h-full pt-5 pb-24'>
      <div className="loginSignup-container bg-black w-3/5 h-full rounded-2xl m-auto px-14 py-8">
        <h1 className='my-5 text-3xl font-bold'>{state}</h1>
        <div className="loginSignup-fields flex flex-col ">
          {state === 'Sign Up'?<input name='username' value={formData.username} onChange={changeHandler} className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="text" placeholder='Your Name' />:<></>}
          <input name='email' value={formData.email} onChange={changeHandler} className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="text" placeholder='E-mail address' />
          <input name='password' value={formData.password} onChange={changeHandler} className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="password" placeholder='Password' />
        </div>
        <button className='w-full bg-white text-black text-xl font-bold my-4 py-3 rounded-4xl border-2 hover:bg-black hover:text-white cursor-pointer' onClick={()=>{state==='Log In'?login():signup()}}>Continue</button>

        {state==='Sign Up'?<p className='loginSignup-login'>Already have an account? <span className='cursor-pointer text-blue-500 underline hover:text-blue-700' onClick={()=>{setState("Log In")}}>LogIn here</span></p>
        :<p className='loginSignup-login'>Create a New account! <span className='cursor-pointer text-blue-500 underline hover:text-blue-700' onClick={()=>{setState("Sign Up")}}>SignUp here</span></p>}
        
        
        <div className="loginSignup-agree flex gap-4 my-3">
          <input type="checkbox" name="" id="" />
          <p>By continuing, I am agreeing to the terms & privacy policies.</p>
        </div>
      </div>
    </div>
  )
}

export default LoginSignup

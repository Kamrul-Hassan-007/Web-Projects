import React from 'react'

const DescriptionBox = () => {
  return (
    <div className='descriptionbox m-24'>
      <div className="descriptionbox-navigator flex items-center">
        <div className="descriptionbox-nav-box text-lg border px-6 py-4 font-bold">Description</div>
        <div className="descriptionbox-nav-box fade text-lg border px-6 py-4 bg-gray-950">Reviews (123)</div>
      </div>
      <div className="descriptionbox-des flex flex-col border gap-8 px-10 py-6">
        <p>This E-commerce is the buying and selling of goods and services over the internet. It is conducted over cloths, T-Shirts, Pants, and other Branded products.</p>
        <p>An e-commerce clothing website is a digital platform that serves as an online store, enabling customers to browse and purchase apparel items virtually. It functions as the virtual equivalent of a physical retail store, utilizing technology to connect sellers and buyers across the globe with enhanced reach and accessibility. </p>
      </div>
    </div>
  )
}

export default DescriptionBox

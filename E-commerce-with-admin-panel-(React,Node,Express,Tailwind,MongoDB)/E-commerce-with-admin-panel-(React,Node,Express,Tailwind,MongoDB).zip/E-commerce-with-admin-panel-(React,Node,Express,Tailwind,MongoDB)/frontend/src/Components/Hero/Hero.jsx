import React from 'react' 
import hand_icon from "../Assets/Frontend_Assets/hand_icon.png"
import arrow_icon from "../Assets/Frontend_Assets/arrow.png"
import hero_image from "../Assets/Frontend_Assets/hero_image.png"

const Hero = () => {
  return (
    <div className='hero h-full bg-gray-900 flex'>
      <div className="hero-left flex flex-1 flex-col justify-center gap-5 pl-44 leading-[1.1] ">

        <h2 className='text-2xl font-bold'>New Arrivals Only !</h2>
        <div>
            <div className="hero-hand-icon flex items-center gap-5">
                <p className='text-6xl font-bold'>New</p>
                <img className='w-24' src={hand_icon} alt="" />
            </div>
            <p className='text-6xl font-bold'>Collection</p>
            <p className='text-6xl font-bold'>For everyone</p>
        </div>
        <div className="hero-latest-btn flex justify-center items-center gap-4 w-3xs h-16 rounded-full mt-7 bg-purple-700 hover:bg-purple-600 font-bold">
            <div>Latest Collection</div>
            <img src={arrow_icon} alt="" />
        </div>

      </div>
      <div className="hero-right flex flex-1 justify-center items-center">
        <img className='w-md' src={hero_image} alt="" />
      </div>
    </div>
  )
}

export default Hero

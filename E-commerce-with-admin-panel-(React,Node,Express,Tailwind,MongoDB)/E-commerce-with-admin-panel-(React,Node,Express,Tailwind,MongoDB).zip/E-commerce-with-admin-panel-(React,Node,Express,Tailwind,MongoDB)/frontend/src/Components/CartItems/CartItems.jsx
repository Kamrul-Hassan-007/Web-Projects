import React, { useContext } from 'react'
import { ShopContext } from '../../Context/ShopContext'
import remove_icon from "../Assets/Frontend_Assets/cart_cross_icon.png"

const CartItems = () => {
    const { all_product, cartItems, removeFromCart, getTotalCartAmount } = useContext(ShopContext)


    return (
        <div className='cartItems my-14 '>
            <div className="cartItems-format-main grid grid-cols-[0.5fr_2fr_1fr_1fr_1fr_1fr] items-center gap-4 mt-32 mb-4 text-lg font-bold mx-16">
                <p>Products</p>
                <p>Title</p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
                <p>Remove</p>
            </div>
            <div className='h-1 w-full bg-purple-700'></div>
            {all_product.map((e) => {
                if (cartItems[e.id] > 0) {
                    return <div key={e.id} className='mx-16'>
                        <div className="cartItems-format grid grid-cols-[0.5fr_2fr_1fr_1fr_1fr_1fr] items-center gap-4 justify-items-start py-4 ">
                            <img src={e.image} alt="" className='cartIcon-product-icon' />
                            <p>{e.name}</p>
                            <p>${e.new_price}</p>
                            <button className='cartItems-quantity border-2 border-purple-700 bg-purple-700 px-5 py-1 rounded-full hover:bg-purple-950 cursor-pointer '>Q: {cartItems[e.id]}</button>
                            <p>${e.new_price * cartItems[e.id]}</p>
                            <div className='flex items-center gap-1'>
                            <img src={remove_icon} className='cursor-pointer' onClick={() => { removeFromCart(e.id) }} alt="" />-1
                            </div>
                        </div>
                        <hr />
                    </div>
                }
                return null
            })}

            <div className="cartitems-down flex justify-between mx-16 my-20">
                <div className="cartitems-total flex flex-col w-2/5">
                    <h1 className='text-3xl font-bold'>Cart Total</h1>
                    <div className='my-10 w-'>
                        <div className="cartitems-total-item flex justify-between py-3">
                            <p>Subtotal</p>
                            <p>${getTotalCartAmount()}</p>
                        </div>
                        <hr />
                        <div className="cartitems-total-item flex justify-between py-3">
                            <p>Shipping Fee</p>
                            <p>Free</p>
                        </div>
                        <hr />
                        <div className="cartitems-total-item flex justify-between py-3">
                            <h3 className='font-bold text-lg'>Total</h3>
                            <h3 className='font-bold text-lg'>${getTotalCartAmount()}</h3>
                        </div>
                    </div>
                    <button className='bg-red-600 font-bold text-lg w-2/3 py-3 rounded-2xl border-2 border-red-600 hover:bg-red-800 cursor-pointer'>PROCEED TO CHECKOUT</button>
                </div>

                <div className="cartitems-promocode w-2/5 flex flex-col">
                    <p className='text-xl font-bold'>If you have a promo code, Enter it here!</p>
                    <div className="cartitems-promobox">
                        <input className='bg-purple-700 px-6 py-3 my-6 outline-none' type="text" placeholder='Promo Code' />
                        <button className='bg-white text-black font-bold px-4 py-3 cursor-pointer hover:bg-gray-200'>SUBMIT</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default CartItems

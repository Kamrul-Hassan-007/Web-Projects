import React from 'react'

const NewsLetter = () => {
  return (
    <div className='newsletter w-2/3 h-auto flex flex-col justify-center items-center m-auto px-24 py-10 mb-32 bg-purple-800 gap-5 rounded-3xl '>
      <h1 className='text-4xl font-bold'>Get Exclusive Offers on Your E-mail</h1>
      <p className='text-xl font-bold'>Subscribe to Our News Letter & stay Updated!</p>
      <input className='bg-purple-500 px-6 py-2 rounded-2xl w-1/2 focus:outline-none'  type="email" placeholder='Your Email id' />
      <button className='bg-purple-500 text-xl font-bold px-8 py-2 rounded-full'>Subscribe</button>
    </div>
  )
}

export default NewsLetter

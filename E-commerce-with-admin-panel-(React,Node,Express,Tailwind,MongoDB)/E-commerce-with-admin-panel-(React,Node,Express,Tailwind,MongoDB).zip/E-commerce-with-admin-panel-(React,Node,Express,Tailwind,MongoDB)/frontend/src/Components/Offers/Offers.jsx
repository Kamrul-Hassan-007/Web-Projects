import React from 'react'
import exclusive_image from "../Assets/Frontend_Assets/exclusive_image.png"

const Offers = () => {
  return (
    <div className='offers w-3/4 rounded-2xl bg-gray-800 flex m-auto px-14'>
      <div className="offers-left flex flex-1 flex-col justify-center gap-2">
        <h1 className='text-7xl font-bold'>Exclusive</h1>
        <h1 className='text-7xl font-bold'>Offers for you</h1>
        <p className='text-2xl font-bold py-5'>Only Best Selling Products</p>
        <button className='bg-purple-700 py-4 font-bold rounded-full hover:bg-purple-600'>Check Now</button>
      </div>
      <div className="offers-right flex flex-1 items-center justify-end">
        <img src={exclusive_image} alt="" />
      </div>
    </div>
  )
}

export default Offers

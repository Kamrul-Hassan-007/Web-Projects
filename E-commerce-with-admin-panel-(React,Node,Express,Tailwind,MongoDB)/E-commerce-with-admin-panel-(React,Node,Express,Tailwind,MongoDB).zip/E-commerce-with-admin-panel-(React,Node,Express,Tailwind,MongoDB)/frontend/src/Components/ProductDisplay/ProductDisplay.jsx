import React, { useContext,useEffect } from 'react'
import star_icon from "../Assets/Frontend_Assets/star_icon.png"
import star_dull_icon from "../Assets/Frontend_Assets/star_dull_icon.png"
import { ShopContext } from '../../Context/ShopContext'

const ProductDisplay = (props) => {
    const {product} = props
    const {addToCart} = useContext(ShopContext)
  return (
    <div className='productdisplay flex mx-16'>
      <div className="productdisplay-left flex gap-4 my-4 ml-2 mr-8 w-2/3 h-full">
        <div className="productdisplay-img-list flex flex-col gap-4 ">
            <img className='h-26 w-32' src={product.image} alt="" />
            <img className='h-26 w-32' src={product.image} alt="" />
            <img className='h-26 w-32' src={product.image} alt="" />
            <img className='h-26 w-32' src={product.image} alt="" />
        </div>
        <div className="productdisplay-img">
            <img className='productdisplay-main-img w-[500px] h-[465px]' src={product.image} alt="" />
        </div>
      </div>
      <div className="productdisplay-right flex flex-col">
        <h1 className='text-2xl font-bold my-2'>{product.name}</h1>
        <div className="productdisplay-right-star flex gap-1 text-sm items-center mt-3">
            <img src={star_icon} alt="" />
            <img src={star_icon} alt="" />
            <img src={star_icon} alt="" />
            <img src={star_icon} alt="" />
            <img src={star_dull_icon} alt="" />
            <p className='text-lg'>(123)</p>
        </div>
        <div className="productdisplay-right-prices flex gap-3 my-3 items-center">
            <div className="productdisplay-price-old line-through text-gray-400  text-xl">${product.old_price}</div>
            <div className="productdisplay-price-new text-2xl font-bold ">${product.new_price}</div>
        </div>
        <div className="productdisplay-right-discription my-4">
            Thi is good cloth....yadi yadi yada..........Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....Buy Now....
        </div>
        <div className="productdisplay-right-size">
            <h1 className='text-xl font-bold mt-6'>Select Size</h1>
            <div className="productdisplay-right-sizes flex gap-3 my-6">
              <div className='border rounded-md px-2.5 font-bold cursor-pointer hover:bg-white hover:text-black'>S</div>
              <div className='border rounded-md px-2.5 font-bold cursor-pointer hover:bg-white hover:text-black'>M</div>
              <div className='border rounded-md px-2.5 font-bold cursor-pointer hover:bg-white hover:text-black'>L</div>
              <div className='border rounded-md px-2.5 font-bold cursor-pointer hover:bg-white hover:text-black'>XL</div>
              <div className='border rounded-md px-2.5 font-bold cursor-pointer hover:bg-white hover:text-black'>XXL</div>
            </div>
        </div>
        <button onClick={()=>{addToCart(product.id)}} className='border-2 border-purple-700 rounded-full my-4 py-2 text-lg font-bold w-1/2 cursor-pointer bg-purple-700 hover:bg-purple-900 hover:border-purple-400'>Add to CART</button>
        <p className="productdisplay-right-category mt-2"><span className='font-bold'>Category :</span> Women, T-Shirt, Crop Top</p>
        <p className="productdisplay-right-category"><span className='font-bold'>Tags :</span> Modern, Latest</p>
      </div>
    </div>
  )
}

export default ProductDisplay

import React from 'react'
import Item from '../Item/Item'
import { useState } from 'react'
import { useEffect } from 'react'

const Popular = () => {

  const [popular_product, setPopular_product] = useState([])

  useEffect(()=>{
    fetch('http://localhost:4000/popularinwomen')
    .then((response)=>response.json())
    .then((data)=>setPopular_product(data))
  },[])

  return (
    <div className='popular flex flex-col items-center gap-4 mb-36'>
      <h1 className='text-5xl font-bold pt-4'>POPULAR IN WOMEN</h1>
      <div className='h-2 w-2xs bg-gray-600 rounded-full'></div>
      <div className="popular-item mt-12 flex gap-7">
          {popular_product.map((item,i)=>{
            return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
          })}
      </div>
    </div>
  )
}

export default Popular

As you can see there is no node_modules in here so..do -' npm i ' in the terminal and to run it do - ' npm run dev '

import React from 'react'
import navlogo from "../../assets/nav-logo.svg"
import navprofile from '../../assets/nav-profile.svg'

const Navbar = () => {
  return (
    <div className='navbar flex items-center justify-between shadow bg-pink-300 px-3 py-1'>
      <img src={navlogo} className='w-48' alt="" />
      <img src={navprofile} className='w-20' alt="" />
    </div>
  )
}

export default Navbar

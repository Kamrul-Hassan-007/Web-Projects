import React, { useState } from 'react'
import upload_area from '../../assets/upload_area.svg'
import './AddProduct.css'

const AddProduct = () => {

    const [image, setImage] = useState(false)
    const [productDetails, setProductDetails] = useState({
        name: "",
        image: "",
        category:"women",
        new_price:Number(""),
        old_price:Number(""),
    })

    const imageHandler = (e) => {
      setImage(e.target.files[0])
    }
    

    const changeHandler = (e) => {
      setProductDetails({...productDetails,[e.target.name]:e.target.value})
    }
    
    const Add_product = async () => {
      console.log(productDetails);
      let product = productDetails

      let formData = new FormData()
      formData.append('product', image)


      const resp = await fetch("http://localhost:4000/upload",{
        method: "POST",
        headers: {
            Accept: 'application/json'
        },
        body: formData,
      })
      const responseData = await resp.json()

      if(responseData.success){
        product.image = responseData.image_url
        
        await fetch('http://localhost:4000/addproduct',{
            method:'POST',
            headers:{
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body:JSON.stringify(product),
        }).then((resp)=>resp.json()).then((data)=>{
            data.success?alert("Product Added"):alert("Failed")
        })
      }
    }
    


    return (
        <>
        
        <div className='addproduct-name Container bg-pink-300 flex flex-col m-auto rounded-xl px-6 py-4 w-1/2 max-h-[88vh] overflow-y-auto'>
            <div className="addproduct-itemfields flex flex-col gap-2">
                <p className='text-lg font-bold pl-2'>Product titel</p>
                <input value={productDetails.name} onChange={changeHandler} className='bg-pink-400 px-4 py-3 rounded-xl outline-none mb-4' type="text" name='name' placeholder='Type Here' />

            </div>
            <div className="addproduct-pice flex mb-4 gap-5">
                <div className="addproduct-itemfields flex flex-col gap-2 w-full">
                    <p className='text-lg font-bold pl-2'>Standerd Price</p>
                    <input value={productDetails.old_price} onChange={changeHandler} className='bg-pink-400 px-4 py-2 rounded-xl outline-none' type="text" name='old_price' placeholder='Add Price Here' />
                </div>

                <div className="addproduct-itemfields flex flex-col gap-2 w-full">
                    <p className='text-lg font-bold pl-2'>Offer Price / New Price</p>
                    <input value={productDetails.new_price} onChange={changeHandler} className='bg-pink-400 px-4 py-2 rounded-xl outline-none' type="text" name='new_price' placeholder='Add Price Here' />
                </div>

            </div>

            <div className="addproduct-itemfields flex flex-col gap-2  mb-6">
                <p className='text-lg font-bold pl-2'>Choose a Product Category</p>
                <select value={productDetails.category} onChange={changeHandler} name="category" className='add-product-category bg-pink-400 px-3 py-1 rounded-xl outline-none w-1/4 '>
                    <option value="women">Women</option>
                    <option value="men">Men</option>
                    <option value="kid">Kid</option>
                </select>
            </div>


            <div className="addproduct-itemfields flex flex-col gap-2">
                <p>Upload Your Images Here !</p>
                <div className='flex'>
                    <label htmlFor="file-input" className='cursor-pointer max-w-2/5'>
                        <img src={image?URL.createObjectURL(image):upload_area} className='thumpnail-img' alt=""/>
                        <input onChange={imageHandler} type="file" name="image" id="file-input" hidden />
                    </label>
                    <button onClick={()=>{Add_product()}} className='addproduct-btn border-3 border-pink-600 bg-pink-600 text-white font-bold px-9.5 ml-4 my-9 rounded-xl cursor-pointer hover:bg-pink-500'>ADD</button>
                </div>
            </div>
        </div>
        </>
    )
}

export default AddProduct

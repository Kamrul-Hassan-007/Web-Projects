import React, { useEffect, useState } from 'react'
import cross_icon from '../../assets/cross_icon.png'
import './ListProduct.css'

const ListProduct = () => {

  const [allproducts, setAllproducts] = useState([])


  const fetchInfo = async () => {
    let res = await fetch('http://localhost:4000/allproducts')
    let metaData = await res.json()
    setAllproducts(metaData)
  }

  useEffect(() => {
    fetchInfo()
  }, [])


  // Logic for removeing products from database

  const remove_product = async (id) => {
    await fetch('http://localhost:4000/removeproduct', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ id })
    })
    await fetchInfo();
  }




  return (
    <div className='listproduct flex flex-col items-center w-full h-full bg-pink-300 m-2 rounded-xl py-6'>
      <h1 className='font-bold text-3xl mb-4'>All Product
        <div className='pinkLine w-full h-1.5 rounded-full bg-pink-600'></div>
      </h1>
      <div className="listproduct-formet-name grid grid-cols-[1fr_3fr_1fr_1fr_1fr_1fr] w-full justify-items-center py-2 mb-3" >
        <p>Products</p>
        <p>Title</p>
        <p>Old price</p>
        <p>New price</p>
        <p>Category</p>
        <p>Remove</p>
      </div>
      <div className='pinkLine w-full h-0.5 bg-pink-600'></div>
      <div className="listproduct-allproducts Container overflow-y-auto max-h-[60vh]">
        {allproducts.map((product, index) => {
          return <div key={index} className='mx-2'>
            <div className="grid grid-cols-[1fr_3fr_1fr_1fr_1fr_1fr] w-full items-center justify-items-center py-3">
              <img src={product.image} className='w-2/3 rounded-md' alt="" />
              <p>{product.name}</p>
              <p>${product.old_price}</p>
              <p>${product.new_price}</p>
              <p>{product.category}</p>
              <img onClick={() => { remove_product(product.id) }} src={cross_icon} alt="" className='cursor-pointer' />
            </div>
            <hr />
          </div>
        })}
      </div>
    </div>
  )
}

export default ListProduct

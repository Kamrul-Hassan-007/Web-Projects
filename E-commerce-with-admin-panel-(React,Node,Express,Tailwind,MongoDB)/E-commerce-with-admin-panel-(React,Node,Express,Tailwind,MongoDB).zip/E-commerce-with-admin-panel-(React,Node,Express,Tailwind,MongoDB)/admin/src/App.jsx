import React from 'react'
import './App.css'
import Navbar from './Components/Navbar/Navbar'
import Admin from './Pages/Admin/Admin'

const App = () => {
  return (
    <div className='m-0 p-0 h-full bg-pink-200 text-black'>
      <Navbar/>
      <Admin/>
      
    </div>
  )
}

export default App

import React from 'react'
import { Link } from 'react-router-dom'

const Item = (props) => {
  return (
    <div className='item w-2xs hover:transform-[scale(1.02)] transition-[0.6s] mb-6'>
      <Link to={`/product/${props.id}`}><img onClick={window.scroll(0,0)} src={props.image} alt="" /></Link>
      <p className='mx-1.5'>{props.name}</p>
      <div className="item-prices flex gap-5">
        <div className="item-price-new text-gray-200 text-lg font-bold">
            ${props.new_price}
        </div>
        <div className="item-price-old text-gray-500 text-lg line-through">
            ${props.old_price}
        </div>
      </div>
    </div>
  )
}

export default Item

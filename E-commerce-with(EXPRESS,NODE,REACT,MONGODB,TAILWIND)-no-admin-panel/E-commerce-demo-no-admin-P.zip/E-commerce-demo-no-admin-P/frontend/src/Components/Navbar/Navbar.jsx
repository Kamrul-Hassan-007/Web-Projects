import React, { useContext } from 'react'
import { useState } from 'react'
import logo from "../Assets/Frontend_Assets/logo.png"
import cart_icon from "../Assets/Frontend_Assets/cart_icon.png"
import "./Navbar.css"
import { Link, Links } from 'react-router-dom'
import { ShopContext } from '../../Context/ShopContext'

const Navbar = () => {

  const [menu, setMenu] = useState("shop")
  const {getTotalCartItems} = useContext(ShopContext)


  return (
    <div className="navbar bg-purple-900 flex justify-between items-center px-6 py-2 fixed w-full top-0 z-10">
      <Link to='/'>
        <div className="nav-logo flex items-center gap-3 cursor-pointer">
          <img className='w-8' src={logo} alt="" />
          <p className='font-bold text-xl'>Shopppper</p>

        </div>
      </Link>
      <ul className="nav-menu flex gap-5 ">
        <li
          className='hover:font-bold cursor-pointer'
          onClick={() => { setMenu("shop") }}><Link to='/'>Shop</Link>{menu === "shop" ? <hr /> : <></>}</li>
        <li
          className='hover:font-bold cursor-pointer'
          onClick={() => { setMenu("mens") }}><Link to='/mens'>Men</Link>{menu === "mens" ? <hr /> : <></>}</li>
        <li
          className='hover:font-bold cursor-pointer'
          onClick={() => { setMenu("womens") }}><Link to='/womens'>Women</Link>{menu === "womens" ? <hr /> : <></>}</li>
        <li
          className='hover:font-bold cursor-pointer'
          onClick={() => { setMenu("kids") }}><Link to='/kids'>Kids</Link>{menu === "kids" ? <hr /> : <></>}</li>
      </ul>
      <div className="nav-login-cart flex gap-3 items-center">
        <Link to='/login'><button className='border-2 rounded-3xl font-bold px-5 py-1.5 cursor-pointer hover:bg-white hover:text-black'>Login</button>
        </Link>
        <Link to='/cart'><img className='invert w-8 h-8 cursor-pointer' src={cart_icon} alt="" />
        </Link>
        <div className="nav-cart-count flex w-5 h-5 justify-center items-center mt-[-30px] ml-[-20px] p-1 text-sm bg-red-500 z-10 rounded-full">{getTotalCartItems()}</div>

      </div>
    </div>
  )
}

export default Navbar

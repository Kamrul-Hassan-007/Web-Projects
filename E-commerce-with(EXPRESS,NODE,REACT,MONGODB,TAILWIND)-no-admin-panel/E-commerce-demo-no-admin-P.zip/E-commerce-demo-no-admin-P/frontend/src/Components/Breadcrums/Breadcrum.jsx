import React from 'react'
import arrow_icon from "../Assets/Frontend_Assets/breadcrum_arrow.png"

const Breadcrum = (props) => {
    const {product} = props

  return (
    <div className='breadcrum flex gap-2 items-center mx-6 my-4 font-bold capitalize'>
      HOME <img className='h-4' src={arrow_icon} alt="" /> SHOP <img className='h-4' src={arrow_icon} alt="" /> {product.category} <img className='h-4' src={arrow_icon} alt="" /> {product.name}
    </div>
  )
}

export default Breadcrum

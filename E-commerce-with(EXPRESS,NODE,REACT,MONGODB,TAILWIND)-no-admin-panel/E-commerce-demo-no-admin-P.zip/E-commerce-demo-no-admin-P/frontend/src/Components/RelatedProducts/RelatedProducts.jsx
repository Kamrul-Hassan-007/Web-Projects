import React from 'react'
import data_product from "../Assets/Frontend_Assets/data"
import Item from "../Item/Item"

const RelatedProducts = () => {
  return (
    <div className='relatedproducts flex flex-col items-center py-26'>
      <h1 className='text-5xl font-bold'>Related Products</h1>
      <div className='w-1/5 h-1.5 bg-white rounded-full mt-6 mb-16'></div>
      <div className="relatedproducts-item flex gap-5">
        {data_product.map((item,i)=>{
            return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
        })}
      </div>
    </div>
  )
}

export default RelatedProducts

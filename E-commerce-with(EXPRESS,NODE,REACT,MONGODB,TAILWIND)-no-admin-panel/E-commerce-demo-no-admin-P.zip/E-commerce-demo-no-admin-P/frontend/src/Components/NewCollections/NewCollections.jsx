import React from 'react'
import new_collection from "../Assets/Frontend_Assets/new_collections"
import Item from '../Item/Item'

const NewCollections = () => {
  return (
    <div className='newcollections flex flex-col items-center gap-4 mb-36'>
      <h1 className='text-5xl font-bold pt-4 mt-36'>NEW COLLECTIONS</h1>
      <div className='h-2 w-2xs bg-gray-600 rounded-full'></div>
      <div className="collectios mt-12 grid grid-cols-4 gap-8">
          {new_collection.map((item,i)=>{
            return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
          })}
      </div>
    </div>
  )
}

export default NewCollections

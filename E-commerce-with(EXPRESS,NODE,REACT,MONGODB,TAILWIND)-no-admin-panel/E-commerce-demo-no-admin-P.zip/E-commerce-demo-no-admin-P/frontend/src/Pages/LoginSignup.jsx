import React from 'react'

const LoginSignup = () => {
  return (
    <div className='loginSignup bg-gray-800 mt-14 w-full h-full pt-5 pb-24'>
      <div className="loginSignup-container bg-black w-3/5 h-full rounded-2xl m-auto px-14 py-8">
        <h1 className='my-5 text-3xl font-bold'>Sign up</h1>
        <div className="loginSignup-fields flex flex-col ">
          <input className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="text" placeholder='Your Name' />
          <input className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="text" placeholder='E-mail address' />
          <input className='bg-gray-800 my-3 py-2 px-5 rounded-xl' type="password" placeholder='Password' />
        </div>
        <button className='w-full bg-white text-black text-xl font-bold my-4 py-3 rounded-4xl border-2 hover:bg-black hover:text-white cursor-pointer'>Continue</button>
        <p className='loginSignup-login'>Already have an account? <span className='cursor-pointer text-blue-500 underline hover:text-blue-700'>Login here</span></p>
        <div className="loginSignup-agree flex gap-4 my-3">
          <input type="checkbox" name="" id="" />
          <p>By continuing, I am agreeing to the terms & privacy policies.</p>
        </div>
      </div>
    </div>
  )
}

export default LoginSignup
